import { Given, When, Then, And } from '@badeball/cypress-cucumber-preprocessor'
import { functions } from '../../page/object'

Given(/^That Buggy Cars Rating website is lunch$/, () => {
	cy.visit('/');
});

When(/^User clicks on the Register button$/, () => {
	functions.clickRegister();
});

When(/^Inputs the appropriate details to register$/, () => {
	functions.registerUser();
});

Then(/^User should be able to register sucessfully$/, () => {
	functions.registerSuccess();
});

When(/^User login in the application$/, () => {
	functions.userLogin();
});

When(/^Navigates to Page$/, () => {
	functions.navigateToPage();
});