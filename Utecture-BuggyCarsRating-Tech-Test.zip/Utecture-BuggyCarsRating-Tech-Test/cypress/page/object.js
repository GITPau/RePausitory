// landing page
username = '.input-sm';
password = '.form-inline > .form-group > [name="password"]';
login = '.btn-success';
register = '.btn-success-outline';
popularmake = ':nth-child(1) > .card > a';
popularmodel = ':nth-child(2) > .card > a > .img-fluid';
overallrating = ':nth-child(3) > .card > a > .img-fluid';

// regstration page
usernameField = '#username';
firstnameField = '#firstName';
lastnameField = '#lastName';
passwordField = '#password';
confirmPasswordField = '#confirmPassword';
registerButton = '.btn-default';
usernameAlert = 'form > :nth-child(1) > :nth-child(3)';
firstnameAlert = ':nth-child(2) > .alert';
lastnameAlert = ':nth-child(3) > .alert';
passwordAlert = ':nth-child(4) > .alert';
passwordError = ':nth-child(5) > .alert';
resultMessage = '.result'

export const functions = {

    clickRegister(){
        cy.get(register).click()
    },

    // have to update username in test data for every successful register
    registerUser(){
        cy.fixture('register').then((data) => {
            cy.get(usernameField).scrollIntoView({duration: 500})
            cy.get(usernameField).type(data.username)
            cy.get(firstnameField).type(data.firstname)
            cy.get(lastnameField).type(data.lastname)
            cy.get(passwordField).type(data.password)
            cy.get(confirmPasswordField).type(data.password)
            cy.screenshot()
            cy.get(registerButton).click({force: true})
        });
    },

    registerSuccess(){
        cy.get(resultMessage).should('exist')
        cy.screenshot()
    },

    userLogin(){
        cy.fixture('vote').then((data) => {
            cy.get(username).type(data.username)
            cy.get(password).type(data.password)
            cy.get(login).click()
            cy.screenshot()
        });
    },

    navigateToPage(){
        cy.fixture('vote').then((data) => {
            if (data.page == 'Popular Make'){
                cy.get(popularmake).click()
            }
            else if (data.page == 'Popular Model'){
                cy.get(popularmodel).click()
            }
            else if (data.page == 'Overall Rating'){
                cy.get(overallrating).click()
            }
        cy.screenshot()
        });
    },

}