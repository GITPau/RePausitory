// import { functions } from '../../shared-objects/calculator-objects'

Given('Open chrome browser and start application', () => {
    cy.visit('https://www.online-calculator.com/full-screen-calculator/');
    // cy.screenshot(); disabling screenshot function as calculator was not used anyway because of object constraints
});

When('I enter following values and press = button', function(dataTable) {
    var strTestCase=dataTable.raw()[0][1];
    cy.log("Test Case: "+strTestCase);
    // just a log of the test case being executed alongside the values from the table
    var strValue1=dataTable.raw()[1][1];
    cy.log("Value 1: "+strValue1);
    // was not able to add the objects as mentioned. but this should be the part where the script clicks the calculator for the first value
    var strOperator=dataTable.raw()[3][1];
    cy.log("Operator: "+strOperator);
    // this should be the part where the script clicks the calculator for the operator to be used
    var strValue2=dataTable.raw()[2][1];
    cy.log("Value 2: "+strValue2);
    // this should be the part where the script clicks the calculator for the second value
    // this should be the part where the script clicks the calculator for the equal sign
  });

Then('I should be able to see', function (table) {
    var strExpected=table.raw()[0][1];
    cy.log("Expected Value: "+strExpected);
    // this should be the part where the script compares the expected with the actual result from the calculator
    // cy.screenshot(); disabling screenshot function as calculator was not used anyway because of object constraints
    // this part should be for the scripts to test the Clear(C) function after every operation
});