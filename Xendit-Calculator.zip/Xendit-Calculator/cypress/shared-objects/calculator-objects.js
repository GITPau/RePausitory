//objects
const calculator = '#fullframe';

//functions
export const functions = {

}    