import { Given, When, Then } from '@badeball/cypress-cucumber-preprocessor'
import { functions } from '../../page/object'

Given(/^That Amaysim website is launch$/, () => {
	cy.visit('/');
});

When(/^User clicks Login link$/, () => {
	functions.clickLoginLink();
});

// using fixture
When(/^Inputs Username Password and clicks Login button$/, () => {
	functions.correctLogin();
});

Then(/^User should be able to login successfully$/, () => {
	functions.verifyLogin();
});

When(/^User manages mobile plans$/, () => {
	functions.manageMobilePlan();
});

When(/^Clicks "([^"]*)" Menu$/, (args1) => {
	functions.clickMenu(args1);
});

// using fixture
Then(/^Discount can be shared and refer your friend$/, () => {
	functions.referFriend();
});