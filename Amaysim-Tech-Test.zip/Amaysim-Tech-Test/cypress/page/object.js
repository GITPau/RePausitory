// HomePage
loginLink = '.nav-utility > :nth-child(2) > .icon-link';
searchLink = '.nav-has-dropdown > .icon-link';

// LoginPage
loginHeader = '.card-header';
usernameField ='#username';
passwordField = '#password';
loginButton = '.arrow-next';

// ServicesPage
loginMessage = '#WelcomeMessage';
managePlan = '.sc-frDJqD';

// PlanPage
header = '.ama-page-header';
menuRefer = '#menu_list > :nth-child(12) > a';

// ReferAFriendPage
copyButton = '#s > span > p';
emailField = '#a';
messageField = '#b';
shareButton = '#c > span > p';
termsLink = '#Widget-Screen > div > form > div.terms-and-conditions-action';


export const functions = {

    clickLoginLink(){
        cy.get(loginLink).should('exist')
        cy.get(loginLink).click()
        cy.get(loginHeader).should('exist')
    },

    // using fixture
    correctLogin(){
        cy.fixture('refer').then((data) => {
            cy.get(usernameField).type(data.username)
            cy.get(passwordField).type(data.password)
            cy.get(loginButton).click()
        });
    },

    verifyLogin(){
        cy.get(loginMessage).should('exist')
    },

    manageMobilePlan(){
        cy.get(managePlan).click()
        cy.get(header).should('exist')
    },

    clickMenu (args1){
        if (args1=='Refer a friend') {
            cy.get(menuRefer).click()
            cy.get(header).should('exist')
        }
        // Additional condition can be added here for other menu
    },

    referFriend(){
        cy.fixture('refer').then((data) => {
            cy.get(emailField).type(data.email)
            // You can clear the message field and add personlize message
            // Or download and read the terms before sharing
            cy.get(shareButton).click()
        });
    }
}