import { Given, When, Then, And } from '@badeball/cypress-cucumber-preprocessor'
import { functions } from '../../page/object'

Given(/^That BNZ demo website is launch$/, () => {
	// added this header part as it was failing on the usual visit url
	cy.visit('/', { headers: { "Accept-Encoding": "gzip, deflate" } } );
});

Given(/^That user clicks on Menu$/, () => {
	functions.clickMenu();
});

When('User clicks on {string} button', function(string) {
	functions.clickMenuButton(string);
});

Then(/^User should be able to navigate to Payees page$/, () => {
	functions.verifyNavigation();
});

When(/^Clicks on Add payee button$/, () => {
	functions.clickAddButton();
});

When(/^User succesfully adds a payee$/, () => {
	functions.addPayee();
});

Then(/^Payee added message is displayed and payee is added in the list of payees$/, () => {
	functions.verifyPayee();
});

When(/^User clicks add button without payee name$/, () => {
	functions.clickAddWOPayee();
});

Then(/^Error message is displayed$/, () => {
	functions.verifyErrorMessage();
});

Then(/^There should be no error message$/, () => {
	functions.verifyNoErrorMessage();
});

Then(/^User should be able to check if list is in ascending order$/, () => {
	functions.checkAscending();
});

When(/^Clicks on name header$/, () => {
	functions.clickNameHeader();
});

Then(/^User should be able to check if list is in descending order$/, () => {
	functions.checkDescending();
});

Then(/^User should be able to select accounts and verify current balance$/, () => {
	functions.selectAccounts();
});

When(/^User Inputs the transfer amount$/, () => {
	functions.transferAmount();
});

Then(/^User should be able to verify that transfer is succesful$/, () => {
	functions.verifyTransfer();
});