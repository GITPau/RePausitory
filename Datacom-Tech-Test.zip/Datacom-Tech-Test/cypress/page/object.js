// client page
menu = '.js-main-menu-btn';
payeesButton = '.js-main-menu-payees > .Button';
payeesHeading = '.CustomPage-heading > :nth-child(2)';
paytransferButton = '.js-main-menu-paytransfer > .Button';

// payees page
payeesTable = '#YouMoney > div > div > div.Payees.js-payees > section > section > div > ul';
addButton = ':nth-child(3) > .Button';
payeenameField = '#ComboboxInput-apm-name';
payeeSelect = '#companyGroup_1560 > .item > .text-wrapper > .text';
addsubmitButton = '.js-submit';
addedMessage = '.message';
addedPayee = '#YouMoney > div > div > div.Payees.js-payees > section > section > div > ul > li:nth-child(5) > div';
toolTip = '.tooltip-panel > .text';
errorMessage = '.error-header';
nameHeader = '.js-payee-name-column > .Language__container';

// pay or transfer page
fromAccount = '[data-testid="from-account-chooser"]';
toAccount = '[data-testid="to-account-chooser"]';
fromSearch = '.searchContainer-0-5-58 > .IconInput-component-0-11__002e1__002e0 > .InputWrapper-component-0-11__002e1__002e0 > .Input-component-0-11__002e1__002e0';
resultFromAccount = '.card-0-5-61';
resultFromAccountBal = 'body > div.ReactModalPortal > div > div > div > div > div.header-0-5-26 > div > div:nth-child(1) > button > div > div > div.content-0-5-64 > p.balance-0-5-67';
toSearch = '.searchContainer-0-5-75 > .IconInput-component-0-11__002e1__002e0 > .InputWrapper-component-0-11__002e1__002e0 > .Input-component-0-11__002e1__002e0';
resultToAccount = 'li > button > :nth-child(1) > .card-0-5-61';
resultToAccountBal = 'body > div.ReactModalPortal > div > div > div > div > div.header-0-5-26 > div > div:nth-child(2) > button > div > div > div.content-0-5-64 > p.balance-0-5-67';
amountField = '.InputWrapper-component-0-11__002e1__002e0';
transferButton = '.Button-component-d-0-11__002e1__002e0 > .Button-wrapper-10-11__002e1__002e0';
transferMessage = '#notification > div';

export const functions = {

    clickMenu(){
        cy.get(menu).click()
    },

    clickMenuButton(string){
        if (string=='Payees') {
            cy.get(payeesButton).click()
        }
        else if (string=='Pay or Transfer') {
            cy.get(paytransferButton).click()
        // can have other menu buttons added to click here
        }
    },

    verifyNavigation(){
        cy.fixture('data').then((data) => {
            cy.url().should('eq', (data.page))
            cy.screenshot()
        });
    },

    clickAddButton(){
        cy.get(addButton).click()
    },

    addPayee(){
        cy.fixture('data').then((data) => {
            cy.get(payeenameField).type(data.payee)
            cy.get(payeeSelect).click()
            cy.screenshot()
            cy.get(addsubmitButton).click()
        });
    },

    verifyPayee(){
        cy.get(addedMessage).should('exist')
        cy.get(addedPayee).should('exist')
        // added wait here to better capture the successful added message
        cy.wait(2000);
        cy.screenshot()
    },

    clickAddWOPayee(){
        cy.get(addsubmitButton).click()
    },

    verifyErrorMessage(){
        cy.fixture('data').then((data) => {
            cy.get(toolTip).should('have.text', data.errorMessage)
            cy.screenshot()
        });
    },

    verifyNoErrorMessage(){
        cy.get(toolTip).should("not.be.visible")
        cy.screenshot()
    },

    checkAscending(){
        cy.get(payeesTable)
          .children()
          .then(list => {
            storeList = list.text();
            cy.log(storeList);
            unsortedList = list.map((index, html) => Cypress.$(html).text()).get();
            sortedList = unsortedList.slice().sort();
            expect(unsortedList, 'List are in Ascending order').to.deep.equal(sortedList);
        });
        cy.screenshot()
    },

    clickNameHeader(){
        cy.get(nameHeader).click()
    },

    checkDescending(){
        cy.get(payeesTable)
          .children()
          .then(list => {
            storeList = list.text();
            cy.log(storeList);
            unsortedList = list.map((index, html) => Cypress.$(html).text()).get();
            sortedList = unsortedList.slice().sort();
            expect(unsortedList, 'List are in Descending order').to.not.equal(sortedList);
        });
        cy.screenshot()
    },

    selectAccounts(){
        cy.fixture('data').then((data) => {
            cy.get(fromAccount).click()
                cy.get(fromSearch).type(data.fromAccount)
                cy.get(resultFromAccount).click()
            cy.screenshot()
            cy.get(toAccount).click()
                cy.get(toSearch).type(data.toAccount)
                cy.get('.balance-0-5-67').then(($el) => {
                    text = $el.text();
                    cy.log(text);
                  });
                cy.get(resultToAccount).click()
            cy.screenshot()
        });
    },

    transferAmount(){
        cy.fixture('data').then((data) => {
            cy.get(amountField).first().type(data.transferAmmount)
            cy.screenshot()
            cy.get(transferButton).click()
        });
    },

    verifyTransfer(){
        cy.get(transferMessage).should('exist')
        // added wait here to better capture the successful transfer message
        cy.wait(2000);
        cy.screenshot()
    },

}