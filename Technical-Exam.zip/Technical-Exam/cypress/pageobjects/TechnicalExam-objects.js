//objects
const contactUS_Link = '#contact-link > a';
const signIN_Link = '#header > div.nav > div > div > nav > div.header_user_info > a';
const signOUT_Link = '#header > div.nav > div > div > nav > div:nth-child(2) > a';
const subjHeading_Dropdown = '#id_contact';

const email_Text = '#email';
const password_Text = '#passwd';
const signIN_Button = '#SubmitLogin > span';
const home_Button = '#center_column > ul > li > a > span';

const personalInfo_Button = '#center_column > div > div:nth-child(1) > ul > li:nth-child(4) > a > span';
const currentPassword_Text = '#old_passwd';
const newsletter_Check = '#newsletter';
const save_Button = '#center_column > div > form > fieldset > div:nth-child(11) > button > span';
const updateInfo_Alert = '#center_column > div > p';

const newsletter_Text = '#newsletter-input';
const newsletter_Button = '#newsletter_block_left > div > form > div > button';
const newsletter_Alert = '#columns > p'

const orderRef_Text = '#id_order';
const message_Text = '#message';
const send_Button = '#submitMessage > span';
const messageSent_Alert = '#center_column > p';
const messageBlank_Alert = '#center_column > div > ol > li';

const emailCreate_Text = '#email_create';
const createAcct_Button = '#SubmitCreate > span';
const emailRegistered_Alert = '#create_account_error > ol > li';

//functions
export const functions = {

    navigateToLink(args){
        if (args=='Contact us') {
            cy.get(contactUS_Link).click();
        } else if (args=='Sign in') {
            cy.get(signIN_Link).click();
        } else if (args=='Sign out') {
            cy.get(signOUT_Link).click();
        }
    },

    signInToAccount(){
        cy.fixture('testdata').then((data) => {
            cy.get(email_Text).clear()
            .type(data.email)
            .should('have.value', data.email);
            cy.get(password_Text).clear()
            .type(data.password)
            .should('have.value', data.password);
            cy.get(signIN_Button).click()
        });
    },

    subscribeToNewsletter(args){
        cy.fixture('testdata').then((data) => {
            cy.get(newsletter_Text).type(data.email)
            .should('have.value', data.email);
            cy.get(newsletter_Button).click()
            cy.wait(3000)
            if (args=='New') {
                cy.get(newsletter_Alert).should('be.visible')
            } else if (args=='Subscribed') {
                cy.get(newsletter_Alert).should('be.visible')
            } 
        });
    },

    updatePersonalInfo(){
        cy.fixture('testdata').then((data) => {
            cy.get(personalInfo_Button).click()
            cy.wait(3000)
            cy.get(currentPassword_Text).type(data.password)
            .should('have.value', data.password);
            cy.get(newsletter_Check).click()
            cy.get(save_Button).click()
            cy.wait(3000)
            cy.get(updateInfo_Alert).should('be.visible')
        });
    },

    sendMessage(args){
        cy.fixture('testdata').then((data) => {
            if (args=='Customer service') {
                cy.get(subjHeading_Dropdown).select(args)
            } else if (args=='Webmaster') {
                cy.get(subjHeading_Dropdown).select(args)
            }        
            cy.get(email_Text).clear()
            .type(data.email)
            .should('have.value', data.email);
        });
    },

    verifyMessage(args){
        cy.fixture('testdata').then((data) => {
            if (args=='Message') {
                cy.get(message_Text).clear()
                .type(data.message)
                .should('have.value', data.message);
            } else if (args=='Blank') {
                cy.get(message_Text).clear()
            }
        cy.get(send_Button).click()   
        });
    },

    messageStatus(args){
        if (args=='Sent') {
            cy.get(messageSent_Alert).should('be.visible')
        } else if (args=='Blank') {
            cy.get(messageBlank_Alert).should('be.visible')
        }
    },
    
    createAccount(args){
        cy.fixture('testdata').then((data) => {
            cy.get(emailCreate_Text).clear()
            .type(data.email)
            .should('have.value', data.email);
        cy.get(createAcct_Button).click()
        cy.wait(3000)
        if (args=="Registered") {
            cy.get(emailRegistered_Alert).should('be.visible')
        } else if (args=='New') {
            //this section to populate fields for new account
            }   
        });
    }
}    