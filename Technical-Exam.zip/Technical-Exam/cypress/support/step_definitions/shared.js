import { functions } from '../../pageobjects/TechnicalExam-objects'

Given('I open Home page', () => {
    cy.visit('http://automationpractice.com/index.php');
    cy.wait(1000)
});

Then('I wait for {string} secs', (string) => {
    cy.wait(string * 1000);
})

Then('I log {string}', (string) => {
    cy.log(string);
    console.log(string);
})

Then('I navigate to {string}', function(string) {
    functions.navigateToLink(string);
})

Then('I should see header {string}', (string) => {
    cy.get('h1')
    .should('contain', string)
})

Then('I sign in to account', () => {
    functions.signInToAccount();
})

Then('I verify subscription to Newsletter {string}', function(string) {
    functions.subscribeToNewsletter(string);
})

Then('I update Personal Information', () => {
    functions.updatePersonalInfo();
})

Then('I send message to {string}', function(string) {
    functions.sendMessage(string);
})

Then('I verify message content {string}', function(string) {
    functions.verifyMessage(string);
})

Then('I verify message status {string}', function(string) {
    functions.messageStatus(string);
})

Then('I verify creation of an account {string}', function(string) {
    functions.createAccount(string);
})