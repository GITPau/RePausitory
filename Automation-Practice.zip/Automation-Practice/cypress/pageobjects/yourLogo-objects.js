//objects
const contactUS_link = '#contact-link > a';
const signIN_link = '#header > div.nav > div > div > nav > div.header_user_info > a';
const subjHeading_dropdown = '#id_contact';
const email_Text = '#email';
const orderRef_Text = '#id_order';
const message_Text = '#message';
const send_Button = '#submitMessage > span';
const messageSent_Alert = '#center_column > p';

const emailCreate_Text = '#email_create';
const createAcct_Button = '#SubmitCreate > span';
const emailRegistered_Alert = '#create_account_error > ol > li';

//functions
export const functions = {

    navigateToLink(args){
        if (args=='Contact us') {
            cy.get(contactUS_link).click();
        } else if (args=='Sign in') {
            cy.get(signIN_link).click();
        }   
    },

    sendMessage(args){
        cy.fixture('testdata').then((data) => {
            if (args=='Customer service') {
                cy.get(subjHeading_dropdown).select(args)
            } else if (args=='Webmaster') {
                cy.get(subjHeading_dropdown).select(args)
            }   
            cy.get(email_Text).clear()
            .type(data.email)
            .should('have.value', data.email);
            cy.get(message_Text).clear()
            .type(data.message)
            .should('have.value', data.message);
        cy.get(send_Button).click()   
        });
    },

    messageSent(){
        cy.get(messageSent_Alert).should('be.visible')
    },

    createAccount(args){
        cy.fixture('testdata').then((data) => {
            cy.get(emailCreate_Text).clear()
            .type(data.email)
            .should('have.value', data.email);
        cy.get(createAcct_Button).click()
        cy.wait(1000)
        if (args=="Registered"){
            cy.get(emailRegistered_Alert).should('be.visible')
        } else if (args=='New') {
            //this section to populate fields for new account
            }   
        });
    }
}    