import { functions } from '../../pageobjects/yourLogo-objects'

Given('I open YourLogo page', () => {
    cy.visit('http://automationpractice.com/index.php');
    cy.wait(1000)
});

Then('I wait for {string} secs', (string) => {
    cy.wait(string * 1000);
})

Then('I log {string}', (string) => {
    cy.log(string);
    console.log(string);
})

Then('I navigate to {string}', function(string) {
    functions.navigateToLink(string);
})

Then('I should see header {string}', (string) => {
    cy.get('h1')
    .should('contain', string)
})

Then('I send message to {string}', function(string) {
    functions.sendMessage(string);
})

Then('I verify successful message sent', () => {
    functions.messageSent();
});

Then('I verify creation of an account {string}', function(string) {
    functions.createAccount(string);
});