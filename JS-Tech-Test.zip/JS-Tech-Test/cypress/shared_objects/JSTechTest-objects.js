//objects
const webTable = 'body > table > tbody';

//edit user
const editLink = 'body > table > tbody > tr:nth-child(1) > td:nth-child(10) > button';
const editLink2 = 'body > table > tbody > tr:nth-child(2) > td:nth-child(10) > button';
const editLink3 = 'body > table > tbody > tr:nth-child(3) > td:nth-child(10) > button';
const editLink4 = 'body > table > tbody > tr:nth-child(4) > td:nth-child(10) > button';
const editLink5 = 'body > table > tbody > tr:nth-child(5) > td:nth-child(10) > button';
const editLink6 = 'body > table > tbody > tr:nth-child(6) > td:nth-child(10) > button';
const editLink7 = 'body > table > tbody > tr:nth-child(7) > td:nth-child(10) > button';
const firstnameText = 'body > div.modal.ng-scope > div.modal-body > form > table > tbody > tr:nth-child(1) > td:nth-child(2) > input';
const lastnameText = 'body > div.modal.ng-scope > div.modal-body > form > table > tbody > tr:nth-child(2) > td:nth-child(2) > input';
const usernameText = 'body > div.modal.ng-scope > div.modal-body > form > table > tbody > tr:nth-child(3) > td:nth-child(2) > input';
const passwordText = 'body > div.modal.ng-scope > div.modal-body > form > table > tbody > tr:nth-child(4) > td:nth-child(2) > input';
const custradioA = 'body > div.modal.ng-scope > div.modal-body > form > table > tbody > tr:nth-child(5) > td:nth-child(2) > label:nth-child(1) > input';
const custradioB = 'body > div.modal.ng-scope > div.modal-body > form > table > tbody > tr:nth-child(5) > td:nth-child(2) > label:nth-child(2) > input';
const roleDropDown = 'body > div.modal.ng-scope > div.modal-body > form > table > tbody > tr:nth-child(6) > td:nth-child(2) > select';
const emailText = 'body > div.modal.ng-scope > div.modal-body > form > table > tbody > tr:nth-child(7) > td:nth-child(2) > input';
const lockCheck = 'body > div.modal.ng-scope > div.modal-body > form > table > tbody > tr:nth-child(9) > td:nth-child(2) > label > input';
const closeButton = 'body > div.modal.ng-scope > div.modal-footer > button.btn.btn-danger';
const saveButton = 'body > div.modal.ng-scope > div.modal-footer > button.btn.btn-success';

//search user
const searchText = 'body > table > thead > tr:nth-child(1) > td > input';

//add user
const addLink = 'body > table > thead > tr:nth-child(2) > td > button';
const cellText = 'body > div.modal.ng-scope > div.modal-body > form > table > tbody > tr:nth-child(8) > td:nth-child(2) > input';

//functions
export const functions = {

    clickLink(args){
        if (args=='Add User') {
            cy.get(addLink).click()
        } else if (args=='Edit') {
            //clicking of the edit link should be dynamic for the other rows
            cy.get(editLink).click()
        }
    },

    checkWebTable(){
      cy.get(webTable)
        .find("tr")
        .then((rows) => {
        //displays number of current rows in table
      cy.log("Current number of row/s in table: "+rows.length);
      cy.screenshot();
      });
    },

    editUser(){
        cy.fixture('testdata').then((data) => {
            cy.get(custradioA).click()
            cy.get(roleDropDown).select(data.role)
            cy.get(lockCheck).uncheck().should('not.be.checked');
            cy.get(saveButton).click()

            //should be dynamic. but since the link is fix and reverts back to initial values and number of rows, then it's okay for now.
            cy.get(editLink2).click()
            cy.get(custradioA).click()
            cy.get(roleDropDown).select(data.role)
            cy.get(lockCheck).uncheck().should('not.be.checked');
            cy.get(saveButton).click()

            cy.get(editLink3).click()
            cy.get(custradioA).click()
            cy.get(roleDropDown).select(data.role)
            cy.get(lockCheck).uncheck().should('not.be.checked');
            cy.get(saveButton).click()

            cy.get(editLink4).click()
            cy.get(custradioA).click()
            cy.get(roleDropDown).select(data.role)
            cy.get(lockCheck).uncheck().should('not.be.checked');
            cy.get(saveButton).click()

            cy.get(editLink5).click()
            cy.get(custradioA).click()
            cy.get(roleDropDown).select(data.role)
            cy.get(lockCheck).uncheck().should('not.be.checked');
            cy.get(saveButton).click()

            cy.get(editLink6).click()
            cy.get(custradioA).click()
            cy.get(roleDropDown).select(data.role)
            cy.get(lockCheck).uncheck().should('not.be.checked');
            cy.get(saveButton).click()

            cy.get(editLink7).click()
            cy.get(custradioA).click()
            cy.get(roleDropDown).select(data.role)
            cy.get(lockCheck).uncheck().should('not.be.checked');
            cy.get(saveButton).click()
            cy.screenshot();
      });
    },

    searchPage(args){
        cy.get(searchText).clear()
          .type(args)
          .should('have.value', args);
        cy.screenshot();
        cy.get(searchText).clear()
    },

    addUserVerify(){
        cy.fixture('testdata').then((data) => {
            //populate fields to add user
            cy.get(firstnameText).clear()
              .type(data.firstname)
              .should('have.value', data.firstname);
            cy.get(lastnameText).clear()
              .type(data.lastname)
              .should('have.value', data.lastname);
            cy.get(usernameText).clear()
              .type(data.username)
              .should('have.value', data.username);
            cy.get(passwordText).clear()
              .type(data.password)
              .should('have.value', data.password);
            cy.get(custradioB).click()
            cy.get(roleDropDown).select(data.role)
            cy.get(emailText).clear()
              .type(data.email)
              .should('have.value', data.email);
            cy.get(cellText).clear()
              .type(data.cellphone)
              .should('have.value', data.cellphone);
            cy.get(saveButton).click()
            //search for the added user to verify
            cy.get(searchText).clear()
              .type(data.lastname)
              .should('have.value', data.lastname);
            cy.screenshot();
            cy.get(searchText).clear()
        });
    },
}    