import { functions } from '../../shared_objects/JSTechTest-objects'

Given('That I open browser and access link', () => {
    cy.visit('http://www.way2automation.com/angularjs-protractor/webtables/');
})

And('I Check Web table', () => {
    functions.checkWebTable();
    //cy.screenshot();
})

And('I should be able to edit user', () => {
    functions.editUser();
    //cy.screenshot();
})

When('I click {string} link', function(string) {
    functions.clickLink(string);
})

When('I search the page for {string}', function(string) {
    functions.searchPage(string);
    //cy.screenshot();
})

Then('I should be able to add a new user and verify', () => {
    functions.addUserVerify();
    //cy.screenshot();
})