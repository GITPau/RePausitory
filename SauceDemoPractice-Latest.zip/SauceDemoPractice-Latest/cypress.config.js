const { defineConfig } = require('cypress');
const createBundler = require("@bahmutov/cypress-esbuild-preprocessor");
// const addCucumberPreprocessorPlugin = require("@badeball/cypress-cucumber-preprocessor").addCucumberPreprocessorPlugin;
const preprocessor = require("@badeball/cypress-cucumber-preprocessor");
// const createEsbuildPlugin = require("@badeball/cypress-cucumber-preprocessor/esbuild").createEsbuildPlugin;
const createEsbuildPlugin = require("@badeball/cypress-cucumber-preprocessor/esbuild");

// If using this approach, just call the key "setupNodeEvents" in the e2e config
async function setupNodeEvents(on, config) {
  await preprocessor.addCucumberPreprocessorPlugin(on, config);

  on(
    "file:preprocessor",
    createBundler({
      plugins: [createEsbuildPlugin.default(config)],
    })
  );

  // Make sure to return the config object as it might have been modified by the plugin.
  return config;
}

module.exports = defineConfig({
  e2e: {
    // async setupNodeEvents(on, config) {
    //   const bundler = createBundler({
    //     plugins: [createEsbuildPlugin(config)],
    //   });

    //   on("file:preprocessor", bundler);
    //   await addCucumberPreprocessorPlugin(on, config);

    //   return config;
    // },

    baseUrl: "https://www.saucedemo.com",
    specPattern: "cypress/e2e/features/*.feature",
    // specPattern: ["cypress/e2e/features/*.feature", "cypress/support/step_definitions/*.js"],
    // specPattern: ["**/*.feature", "**/**/**/*.{js,jsx,ts,tsx}"],
    chromeWebSecurity: false,
    setupNodeEvents,
  }
})