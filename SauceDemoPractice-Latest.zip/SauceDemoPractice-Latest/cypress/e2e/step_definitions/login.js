import { Given, When, Then, And } from '@badeball/cypress-cucumber-preprocessor'
import { functions } from '../../page/object'
// const loginPage = require('../../page/object')

Given(/^That SwagLab website is launch$/, () => {
	cy.visit('/');
});

// using fixture
When(/^User Inputs Username$/, () => {
	functions.typeUsernameF();
});

When(/^User Inputs Password$/, () => {
	functions.typePasswordF();
});

When(/^Clicks the Login button$/, () => {
	functions.clickLogin();
});

Then(/^User should be able to login successfully$/, () => {
	functions.verifyLogin();
});

Then(/^The error message should be displayed$/, () => {
	functions.verifyErrorMessageF();
});

// static
When(/^User Inputs Username "([^"]*)"$/, (args1) => {
	functions.typeUsername(args1);
});

When(/^User Inputs Password "([^"]*)"$/, (args1) => {
	functions.typePassword(args1);
});

Then(/^The error message "([^"]*)" should be displayed$/, (args1) => {
	functions.verifyErrorMessage(args1);
});

// username and password from table
When(/^User Inputs incorrect credentials$/, (table) => {
	table.hashes().forEach((row) => {
		functions.typeUsername(row.username);
		functions.typePassword(row.password);
	});
});