// LoginPage Objects
usernameField = '[data-test="username"]';
passwordField = '[data-test="password"]';
loginButton = '[data-test="login-button"]';
errorMessage ='h3[data-test="error"]';

// InventoryPage Objects
titleSpan = '.title';

export const functions = {

    // using fixture
    typeUsernameF(){
        cy.fixture('login').then((data) => {
            cy.get(usernameField).type(data.username)
        });
    },

    typePasswordF(){
        cy.fixture('login').then((data) => {
            cy.get(passwordField).type(data.password)
        });
    },

    clickLogin(){
        cy.get(loginButton).click();
    },

    verifyErrorMessageF(){
        cy.fixture('login').then((data) => {
            cy.get(errorMessage).should('have.text', data.errorMessage)
        });
    },

    // static
    typeUsername(args1){
        cy.get(usernameField).type(args1);
    },

    typePassword(args1){
        cy.get(passwordField).type(args1);
    },

    verifyLogin(){
        cy.get(titleSpan).should('have.text', 'Products')
    },

    verifyErrorMessage(args1){
        cy.get(errorMessage).should('have.text', args1)
    },

}

// class loginPage {
    
//     elements = {
//         usernameField: () => cy.get('[data-test="username"]'),
//         passwordField: () => cy.get('[data-test="password"]'),
//         loginButton: () => cy.get('[data-test="login-button"]'),
//         errorMessage: () => cy.get('h3[data-test="error"]')
//     }

//     typeUsername(username) {
//         cy.elements.usernameField().type(username);
//     }

//     typePassword(password) {
//         cy.elements.passwordField().type(password);
//     }

//     clickLogin() {
//         cy.elements.loginButton().click
//     }
// }

// module.exports = new loginPage();

// class inventoryPage {
    
//     elements = {
//         titleSpan: () => cy.get('.title')
//     }

//     verifyLogin() {
//         cy.elements.titleSpan.should('have.text', 'Products')
//     }
// }

// module.exports = new inventoryPage();