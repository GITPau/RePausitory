package stepdefs;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import static org.junit.Assert.assertTrue;

public class StepDefinitions {
    WebDriver webDriver;
    WebDriverWait wait;
    ArrayList<String> tabs;
    String emailHolder, emailCondition;
    String errorHandler;
    String verificationCode;

    public void callWebDriver() throws InterruptedException {
        System.setProperty("webdriver.chrome.driver","C:/PersonalRuns/driver/chromedriver.exe");
        webDriver = new ChromeDriver();
        webDriver.manage().window().maximize();
        wait = new WebDriverWait(this.webDriver,10);
        String baseUrl = "https://www.google.com.my/?hl=ms";
        webDriver.get(baseUrl);
        webDriver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"t");
        tabs = new ArrayList<String> (webDriver.getWindowHandles());
        Thread.sleep(2000);
    }

    public void switchTab(int i) throws Throwable {
        try {
            Thread.sleep(2000);
            webDriver.switchTo().window(tabs.get(i));
        } catch (Exception e){
            e.printStackTrace();
            Assert.assertEquals("Is an exception occurred?","Yes","No");
            webDriver.quit();
        }
    }

    public void successFetchCode() throws Throwable {
        try {
            Thread.sleep(2000);
            switchTab(1);
            webDriver.navigate().refresh();
            Thread.sleep(2000);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='schranka']/tr[1]/td[2]")));
            WebElement element = this.webDriver.findElement(By.xpath("//*[@id='schranka']/tr[1]/td[2]"));
            String splitter[] = element.getText().split(" ");
            verificationCode = splitter[0];
            i_take_screenshot();
            switchTab(0);
            Thread.sleep(2000);
        } catch (Exception e){
            e.printStackTrace();
            Assert.assertEquals("Is an exception occurred?","Yes","No");
            webDriver.quit();
        }
    }

    public void makeClickPage() throws Throwable{
        try {
            Actions actions = new Actions(webDriver);
            Robot robot = new Robot();
            robot.mouseMove(50,50);
            actions.click().build().perform();
            robot.mouseMove(200,70);
            actions.click().build().perform();
        } catch (Exception e){
            e.printStackTrace();
            Assert.assertEquals("Is an exception occurred?","Yes","No");
            webDriver.quit();
        }
    }

    @Given("^I want to visit a temporary email generator site$")
    public void i_want_to_visit_a_temporary_email_generator_site() throws Throwable {
        try {
            callWebDriver();
            switchTab(1);
            webDriver.get("https://www.tempmailaddress.com/");
            Thread.sleep(2000);
        } catch (Exception e){
            e.printStackTrace();
            Assert.assertEquals("Is an exception occurred?","Yes","No");
            webDriver.quit();
        }
    }

    @Given("^I want to generate a disposable email$")
    public void i_want_to_generate_a_disposable_email() throws Throwable{
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='email']")));
            WebElement x = this.webDriver.findElement(By.xpath("//*[@id='email']"));
            emailHolder = x.getText().trim();
            System.out.println(emailHolder);
        } catch (Exception e){
            e.printStackTrace();
            Assert.assertEquals("Is an exception occurred?","Yes","No");
            webDriver.quit();
        }
    }

    @When("^I want to visit facebook site and sign up$")
    public void i_want_to_visit_facebook_site_and_sign_up() throws Throwable {
        try {
            switchTab(0);
            webDriver.get("https://en-gb.facebook.com");
            Thread.sleep(2000);
            assertTrue("Assert that title starts with Facebook",this.webDriver.getTitle().startsWith("Facebook"));
        } catch (Exception e){
            e.printStackTrace();
            Assert.assertEquals("Is an exception occurred?","Yes","No");
            webDriver.quit();
        }
    }

    @When("^I enter my first name: '(.*)'$")
    public void i_enter_my_first_name(String criteria) throws Throwable{
        try {
            String[] FirstNames = {"Ronaldo","Pedro","Salvador","Eddie","Paulo","Christopher","Eric"};
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='u_0_l']")));
            WebElement element = this.webDriver.findElement(By.xpath("//*[@id='u_0_l']"));
            if(criteria.equalsIgnoreCase("RANDOM")){
                element.sendKeys(FirstNames[(int) Math.random()*7]);
            } else if (criteria.length() == 0){
                element.sendKeys("");
                errorHandler = "FNBlank";
            } else {
                element.sendKeys(criteria);
            }
        } catch (Exception e){
            e.printStackTrace();
            Assert.assertEquals("Is an exception occurred?","Yes","No");
            webDriver.quit();
        }
    }

    @When("^I enter my last name: '(.*)'$")
    public void i_enter_my_last_name(String criteria) throws Throwable{
        try {
            String[] LastNames = {"Duterte","Revilla","Santos","De Santa","Goh","Garcia","Zamora"};
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='u_0_n']")));
            WebElement element = this.webDriver.findElement(By.xpath("//*[@id='u_0_n']"));
            if(criteria.equalsIgnoreCase("RANDOM")){
                element.sendKeys(LastNames[(int) Math.random()*7]);
            } else if (criteria.length() == 0){
                element.sendKeys("");
                errorHandler = "LNBlank";
            } else {
                element.sendKeys(criteria);
            }
        } catch (Exception e){
            e.printStackTrace();
            Assert.assertEquals("Is an exception occurred?","Yes","No");
            webDriver.quit();
        }
    }

    @When("^I enter my disposable email: '(.*)'$")
    public void i_enter_my_disposable_email(String criteria) throws Throwable{
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='u_0_q']")));
            WebElement element = this.webDriver.findElement(By.xpath("//*[@id='u_0_q']"));
            if(criteria.equalsIgnoreCase("DISPOSABLE")){
                element.sendKeys(emailHolder);
                emailCondition = "0";
            } else if (criteria.length() == 0){
                element.sendKeys("");
                errorHandler = "EABlank";
                emailCondition = "1";
            } else {
                element.sendKeys(criteria);
                emailCondition = criteria;
            }
        } catch (Exception e){
            e.printStackTrace();
            Assert.assertEquals("Is an exception occurred?","Yes","No");
            webDriver.quit();
        }
    }

    @When("^I re-confirm my disposable email$")
    public void i_re_confirm_my_disposable_email() throws Throwable{
        try {
            if (emailCondition.equalsIgnoreCase("0")) {
                wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='u_0_t']")));
                WebElement element = this.webDriver.findElement(By.xpath("//*[@id='u_0_t']"));
                element.sendKeys(emailHolder);
            } else if (emailCondition.equalsIgnoreCase("1")) {
                // Do not do anything
            } else {
                wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='u_0_t']")));
                WebElement element = this.webDriver.findElement(By.xpath("//*[@id='u_0_t']"));
                element.sendKeys(emailCondition);
            }
        } catch (Exception e){
            e.printStackTrace();
            Assert.assertEquals("Is an exception occurred?","Yes","No");
            webDriver.quit();
        }
    }

    @When("^I enter my password: '(.*)'$")
    public void i_enter_my_password(String criteria) throws Throwable{
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='u_0_x']")));
            WebElement element = this.webDriver.findElement(By.xpath("//*[@id='u_0_x']"));
            if(criteria.length() == 0){
                element.sendKeys("");
                errorHandler = "PWBlank";
            } else {
                element.sendKeys(criteria);
            }
        } catch (Exception e){
            e.printStackTrace();
            Assert.assertEquals("Is an exception occurred?","Yes","No");
            webDriver.quit();
        }
    }

    @When("^I enter my birthday: '(.*)'$")
    public void i_enter_my_birthday(String criteria) throws Throwable{
        try {
            String[] MonthList = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sept","Oct","Nov","Dec"};
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='day']")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='month']")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='year']")));
            Select BDay = new Select(this.webDriver.findElement(By.xpath("//*[@id='day']")));
            Select BMonth = new Select(this.webDriver.findElement(By.xpath("//*[@id='month']")));
            Select BYear = new Select(this.webDriver.findElement(By.xpath("//*[@id='year']")));
            if (criteria.equalsIgnoreCase("RANDOM")){
                BDay.selectByVisibleText(String.valueOf((int) Math.random()*28+1));
                BMonth.selectByVisibleText(MonthList[(int) (Math.random()*12)]);
                BYear.selectByVisibleText(String.valueOf(1965 + (int)Math.round(Math.random() * (1965 - 1994))));
            } else if (criteria.length() == 0){
                // Do nothing and retain the default value
            } else {
                String trimCriteria = criteria.replaceAll("[^a-zA-Z]+","-").trim();
                String[] list = trimCriteria.split("-");
                BDay.selectByVisibleText(list[0]);
                BMonth.selectByVisibleText(list[1]);
                BYear.selectByVisibleText(list[2]);
            }
        } catch (Exception e){
            e.printStackTrace();
            Assert.assertEquals("Is an exception occurred?","Yes","No");
            webDriver.quit();
        }
    }

    @When("^I select my gender: '(.*)'$")
    public void i_select_my_gender(String criteria) throws Throwable {
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@class='_5k_3']/span['1']/input")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@class='_5k_3']/span['2']/input")));
            if (criteria.equalsIgnoreCase("RANDOM")){
                int genderCounter = (int) Math.random()*2+1;
                WebElement Gender = this.webDriver.findElement(By.xpath("//*[@class='_5k_3']/span["+genderCounter+"]/input"));
                Gender.click();
            } else if (criteria.length() == 0){
                // Do nothing and retain radio buttons un-clicked
                errorHandler = "GBlank";
            } else if (criteria.equalsIgnoreCase("Female")){
                WebElement Gender = this.webDriver.findElement(By.xpath("//*[@class='_5k_3']/span['1']/input"));
                Gender.click();
            } else {
                WebElement Gender = this.webDriver.findElement(By.xpath("//*[@class='_5k_3']/span['2']/input"));
                Gender.click();
            }
        } catch (Exception e){
            e.printStackTrace();
            Assert.assertEquals("Is an exception occurred?","Yes","No");
            webDriver.quit();
        }
    }

    @When("^I click Sign Up$")
    public void i_click_Sign_Up() throws Throwable {
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='u_0_15']")));
            WebElement SubmitButton = this.webDriver.findElement(By.xpath("//*[@id='u_0_15']"));
            SubmitButton.click();
            Thread.sleep(10000);
        } catch (Exception e){
            e.printStackTrace();
            Assert.assertEquals("Is an exception occurred?","Yes","No");
            webDriver.quit();
        }
    }

    public boolean isElementPresent(By by) {
        try {
            webDriver.findElement(by);
            return true;
        }
        catch (org.openqa.selenium.NoSuchElementException e) {
            return false;
        }
    }

    @Then("^I should be either on the landing page or hitting an expected error based on scenario: '(.*)'$")
    public void i_should_be_either_on_the_landing_page_or_hitting_an_expected_error_based_on_scenario(String criteria) throws Throwable {
        try {
            if (criteria.equalsIgnoreCase("POSITIVE")){
                Boolean checkError = this.webDriver.findElements(By.xpath("//*[@id='reg_error_inner']")).size() != 0;
                i_take_screenshot();
                if (!checkError){
                    makeClickPage();
                    successFetchCode();
                    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='code_in_cliff']")));
                    WebElement elementField = this.webDriver.findElement(By.xpath("//*[@id='code_in_cliff']"));
                    elementField.sendKeys(verificationCode);
                    Thread.sleep(1000);
                    Robot robot = new Robot();
                    robot.keyPress(KeyEvent.VK_ENTER);
                    robot.keyRelease(KeyEvent.VK_ENTER);
                    robot.delay(200);
                    i_take_screenshot();
                    Thread.sleep(6000);
                } else {
                    WebElement element = this.webDriver.findElement(By.xpath("//*[@id='reg_error_inner']"));
                    Assert.assertEquals("Error Handling for Expected Error Message","There was an error with your registration. Please try registering again.",element.getText());
                    System.out.println("Facebook was able to identify that my registration is suspicious." + "\n") ;
                }
            } else {
                Thread.sleep(2000);
                assertTrue("Error Handling for Visibility of Error Message",isElementPresent(By.xpath("//*[@id='globalContainer']/div[3]/div/div/div")));
                wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='globalContainer']/div[3]/div/div/div")));
                WebElement element = this.webDriver.findElement(By.xpath("//*[@id='globalContainer']/div[3]/div/div/div"));
                if (errorHandler.equalsIgnoreCase("FNBlank")) {
                    Assert.assertEquals("Error Handling for Expected Error Message","What's your name?",element.getText());
                } else if (errorHandler.equalsIgnoreCase("LNBlank")) {
                    Assert.assertEquals("Error Handling for Expected Error Message","What's your name?",element.getText());
                } else if (errorHandler.equalsIgnoreCase("EABlank")) {
                    Assert.assertEquals("Error Handling for Expected Error Message","You'll use this when you log in and if you ever need to reset your password.",element.getText());
                } else if (errorHandler.equalsIgnoreCase("PWBlank")) {
                    Assert.assertEquals("Error Handling for Expected Error Message","Enter a combination of at least six numbers, letters and punctuation marks (like ! and &).",element.getText());
                } else if (errorHandler.equalsIgnoreCase("GBlank")) {
                    Assert.assertEquals("Error Handling for Expected Error Message", "Please choose a gender. You can change who can see this later.", element.getText());
                }
            }
        } catch (Exception e){
            e.printStackTrace();
            Assert.assertEquals("Is an exception occurred?","Yes","No");
            webDriver.quit();
        }
    }

    File srcFile = new File("");
    String rootPath = srcFile.getAbsolutePath() + "/src/test/resources/Screenshots/Screenshots";
    @Then("^I take screenshot$")
    public void i_take_screenshot() throws Throwable{
        try {
            Date LogDate = new Date();
            SimpleDateFormat screenshotLog = new SimpleDateFormat("yyyyMMddHHmmssSSS");
            File src = ((TakesScreenshot)webDriver). getScreenshotAs(OutputType. FILE);
            String path = rootPath + screenshotLog.format(LogDate) + ".png";
            System.out.println(path);
            FileUtils. copyFile(src, new File(path));
        } catch (Exception e){
            e.printStackTrace();
            Assert.assertEquals("Is an exception occurred?","Yes","No");
            webDriver.close();
        }
    }
}
